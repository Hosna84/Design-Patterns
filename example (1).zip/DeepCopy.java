package org.example;

import java.lang.reflect.*;
import java.util.*;

public class DeepCopy {
    public Object clone(Object object) throws NoSuchMethodException, InvocationTargetException,
            InstantiationException, IllegalAccessException {
        Class<?> clazz = object.getClass();
        Constructor<?> cunsructor = clazz.getDeclaredConstructor();
        cunsructor.setAccessible(true);
        Object newObj = cunsructor.newInstance();
        while (clazz != null) {
            for (Field field : clazz.getDeclaredFields()) {
                field.setAccessible(true);
                field.set(newObj, field.get(object));
                if (field.get(object) instanceof ArrayList) {
                    field.set(newObj, new ArrayList<>());
                } else if (!(field.get(object) instanceof ArrayList)) field.set(newObj, field.get(object));
            }
            clazz = clazz.getSuperclass();
        }
        return newObj;
    }
}
